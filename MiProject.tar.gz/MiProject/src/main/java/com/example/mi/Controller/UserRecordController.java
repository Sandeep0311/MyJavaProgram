package com.example.mi.Controller;

import com.example.mi.Entity.UserRecord;
import com.example.mi.Service.UserRecordService;
import com.example.mi.dto.AddUserRecordDTO;
import com.example.mi.dto.UserStepsRequestDTO;
import com.example.mi.dto.UserStepsResponseDTO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import java.util.List;

@RestController
public class UserRecordController {
    @Autowired
    UserRecordService userRecordService;
    //for add and update steps
    @RequestMapping(value = "/updateOrAddUsrSteps", method = RequestMethod.POST)
    public String addOrUpdateRecord(@RequestBody AddUserRecordDTO addUserRecordDTO){
        if (userRecordService.addOrUpdateRecord(addUserRecordDTO)) {
            return "user updated/added Successfully.";
        }
        return "user didn't update";
    }

    //for showing steps
    @RequestMapping(value = "/showSteps", method = RequestMethod.POST,produces = MediaType.APPLICATION_JSON_VALUE)
    public List<UserStepsResponseDTO> addOrUpdateRecord(@RequestBody UserStepsRequestDTO userStepsRequestDTO){
        return userRecordService.findSteps(userStepsRequestDTO);
    }

    // for add User Records
    @RequestMapping(value = "/addUserRecords", method = RequestMethod.POST)
    public ModelAndView addUserRecords(Model model){
        ModelAndView modelAndView = new ModelAndView();
        UserRecord userRecord = new UserRecord();
        modelAndView.addObject("UserRecord", userRecord);
        modelAndView.setViewName("/addUserRecord");
        return modelAndView;
    }

    //for showing steps of particular user on web
    @RequestMapping(value = "/showUserSteps", method = RequestMethod.POST)
    public ModelAndView userSteps(@RequestBody UserStepsRequestDTO userStepsRequestDTO){
        ModelAndView modelAndView = new ModelAndView();
        List<UserStepsResponseDTO> stepsList = userRecordService.findSteps(userStepsRequestDTO);
        modelAndView.addObject("stepList", stepsList);
        modelAndView.setViewName("/steps");
        return modelAndView;
    }

}
