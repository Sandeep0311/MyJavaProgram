package com.example.mi.Controller;


import com.example.mi.Common.GenericResponseDTO;
import com.example.mi.co.LoginCo;
import com.example.mi.Service.UserLoginService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;

@RestController
public class UserLoginController {
    @Autowired
    UserLoginService userLoginService;

@RequestMapping(value = "/api/login", method = RequestMethod.POST)
    public @ResponseBody GenericResponseDTO<String> login(@RequestBody LoginCo loginCo){
    String token = userLoginService.authenticate(loginCo.getEmailId(), loginCo.getPassword());
    GenericResponseDTO responseDTO = new GenericResponseDTO();
    if(token == null) {
        responseDTO.setStatus("false");
        responseDTO.setMessage("Invalid Username or Password");
    }else{
        responseDTO.setStatus("true");
        responseDTO.setMessage("Login Success");
        responseDTO.setData(token);
    }
    return responseDTO;
}

    @RequestMapping(value={"/", "/login"}, method = RequestMethod.GET)
    public ModelAndView login(){
        ModelAndView modelAndView = new ModelAndView();
        modelAndView.setViewName("login");
        return modelAndView;
    }


/*    @RequestMapping(value = "/addUser", method = RequestMethod.POST)
    public String addUser(@RequestBody AddUserLoginDTO addUserLoginDTO) {
        ModelAndView modelAndView = new ModelAndView();

        if(userLoginService.addUser(addUserLoginDTO)) {
            return "User added Successfully";
        }
        return "User Already Exists.";
    }*/

}
