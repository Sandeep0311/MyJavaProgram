package com.example.mi.Service;

import org.springframework.stereotype.Service;

public interface UserLoginService {

   // boolean addUser(AddUserLoginDTO addUserLoginDTO);
    String authenticate(String email, String password);
}
