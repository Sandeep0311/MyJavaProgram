package com.example.mi.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import java.math.BigDecimal;

@JsonIgnoreProperties(ignoreUnknown = true)
public class AddUserRecordDTO {
    private BigDecimal steps;

    public BigDecimal getSteps() {
        return steps;
    }

    public void setSteps(BigDecimal steps) {
        this.steps = steps;
    }
}
