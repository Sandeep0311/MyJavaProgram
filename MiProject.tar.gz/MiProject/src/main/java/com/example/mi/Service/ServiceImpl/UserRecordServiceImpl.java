package com.example.mi.Service.ServiceImpl;

import com.example.mi.Entity.UserRecord;
import com.example.mi.Service.UserRecordService;
import com.example.mi.dao.UserRecordRepository;
import com.example.mi.dto.AddUserRecordDTO;
import com.example.mi.dto.UserStepsRequestDTO;
import com.example.mi.dto.UserStepsResponseDTO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

@Service
public class UserRecordServiceImpl implements UserRecordService {

    @Autowired
    UserRecordRepository userRecordRepository;

    @Override
    public boolean addOrUpdateRecord(AddUserRecordDTO addUserRecordDTO) {
        UserRecord userRecord = new UserRecord();

        SimpleDateFormat dateMonthYear = new SimpleDateFormat("DD-MM-YYYY");
        String oldDate = dateMonthYear.format(userRecord.getDate());
        String newDate = dateMonthYear.format(new Date());

        if(oldDate == newDate){
            userRecord.setSteps(addUserRecordDTO.getSteps());
            userRecord.setDate(new Date());
        }
        else{
            UserRecord userRecord1 = new UserRecord();
            userRecord1.setSteps(addUserRecordDTO.getSteps());
            userRecord1.setDate(new Date());
        }
        return false;
    }

    @Override
    public List<UserStepsResponseDTO> findSteps(UserStepsRequestDTO userStepsRequestDTO) {
        List<UserRecord> userRecord = userRecordRepository.findUserRecordsByDateAfterAndDateBeforeAndEmailId(userStepsRequestDTO.getFromDate(), userStepsRequestDTO.getToDate(), userStepsRequestDTO.getEmailId());
        List<UserStepsResponseDTO> responseDTOs = new ArrayList<>();
        for (int i = 0; i <userRecord.size() ; i++) {
            UserStepsResponseDTO responseDTO = new UserStepsResponseDTO();
            responseDTO.setSteps(String.valueOf(userRecord.get(i).getSteps()));
            responseDTOs.add(responseDTO);
        }
        return responseDTOs;
    }

    @Override
    public void addUserRecords(UserRecord userRecord) {

    }

    @Override
    public UserRecord updateSteps(int userEmailId) {

        return null;
    }
}
