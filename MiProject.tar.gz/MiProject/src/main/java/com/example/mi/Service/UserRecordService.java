package com.example.mi.Service;

import com.example.mi.Entity.UserRecord;
import com.example.mi.dto.AddUserRecordDTO;
import com.example.mi.dto.UserStepsRequestDTO;
import com.example.mi.dto.UserStepsResponseDTO;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public interface UserRecordService {
    boolean addOrUpdateRecord(AddUserRecordDTO addUserRecordDTO);

    List<UserStepsResponseDTO> findSteps(UserStepsRequestDTO userStepsRequestDTO);
    void addUserRecords(UserRecord userRecord);
    UserRecord updateSteps(int userEmailId);


}
