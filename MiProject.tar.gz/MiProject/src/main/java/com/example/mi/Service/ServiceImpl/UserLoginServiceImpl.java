package com.example.mi.Service.ServiceImpl;

import com.example.mi.Common.UserToken;
import com.example.mi.Common.UserToken;
import com.example.mi.Service.UserLoginService;
import com.example.mi.Entity.UserLogin;
import com.example.mi.dao.UserLoginRepositry;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;

import org.springframework.stereotype.Service;

import java.util.UUID;

 @Service
public class UserLoginServiceImpl implements UserLoginService {

    @Autowired
    UserLoginRepositry userLoginRepositry;

    @Autowired
    private BCryptPasswordEncoder encoder;


    @Override
    public String   authenticate(String emailId, String password) {

        UserLogin user = userLoginRepositry.findByEmailId(emailId);
        if(user!= null && encoder.matches(password, user.getPassword())){
            String token = UUID.randomUUID().toString();
            UserToken.addToken(token, emailId);
            return token;
        }
        return null;
    }

    public void logout(String token, String email){
        String emailId = UserToken.getEmail(token);
        if(email.equals(emailId)){
            UserToken.removeToken(token);
        }
    }




/*
    @Override
    public boolean addUser(AddUserLoginDTO addUserLoginDTO) {
        UserLogin user = userLoginRepositry.findUserLoginByEmailId(addUserLoginDTO.getEmailId());
        if(user ==null) {
            UserLogin userLogin = new UserLogin();
            userLogin.setUsername(addUserLoginDTO.getUsername());
            userLogin.setPassword(addUserLoginDTO.getPassword());
            userLogin.setDate(new Date());
            userLogin.setRole(Role.USER);
            userLogin.setEmailId(addUserLoginDTO.getEmailId());
            Date date1 = new Date();
            date1.getTime();
            userLoginRepositry.save(userLogin);

            return true;
        }
        return false;
    }
*/

}
