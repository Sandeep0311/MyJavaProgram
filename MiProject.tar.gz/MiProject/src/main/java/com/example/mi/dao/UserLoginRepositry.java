package com.example.mi.dao;

import com.example.mi.Entity.UserLogin;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Date;

@Repository
public interface UserLoginRepositry extends JpaRepository<UserLogin, Long> {
    UserLogin findUserLoginByEmailId(String emailId);
    UserLogin findByEmailId(String emailId);
}
