package com.example.mi.Common;

import java.util.HashMap;
import java.util.Map;

public class UserToken {
    private static Map<String, String> tokenMap = new HashMap<>();

    public static String getEmail(String token){
        return tokenMap.get(token);
    }

    public static void addToken(String token, String email){
        tokenMap.put(token, email);
    }

    public static void removeToken(String token){
        tokenMap.remove(token);
    }
}
